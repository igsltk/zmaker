package org.ggpi.ZMaker;

public class Main {
	public static void main(String args[]) {
		GUIapp app = new GUIapp();
		app.setVisible(true);
	}
}
